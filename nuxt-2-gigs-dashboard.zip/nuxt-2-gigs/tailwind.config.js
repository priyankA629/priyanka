/** @type {import('tailwindcss').Config} */
module.exports = {
  purge: ['./components/**/*.{vue,js}', './pages/**/*.{vue,js}'],
  content: [
    "./components/DragableColumn.vue",
    "./components/Header.vue",
    "./components/Kanbancard.vue",
    "./components/KanbanTabs.vue",
    "./components/MainContent.vue",
    "./components/Navigation.vue",
    "./components/Sidebar.vue",
    "./layouts/dashboard.vue",
    "./layouts/default.vue",
    "./pages/index.vue",
    "./pages//project.vue",
    "./plugins/**/*.{js,ts}",
    "./nuxt.config.js",
    "./error.vue",
  ],
  theme: {
    extend: {
      colors: {
        customPurple: '#800080',
        customBackground: '#f8f9fa',
        customText: '#333333',
        customtextBg: '#ededed',
        customTransparent: '#f2e6f2',
        customWhite: '#fffff',
      },
      borderColor: {
        'custom-purple': '#800080',
        'custom-green': '#10b981',
        'custom-orange': '#f97316',
      },
      textColor: {
        'primary': '#333333',
        'secondary': '#ffed4a',
        'danger': '#e3342f',
      },
      fontFamily: {
        sans: ['Poppins', 'sans-serif'], 
      },
      borderWidth: {
        DEFAULT: '1px',
        '0': '0',
        '2': '2px',
       '3': '3px',
        '4': '4px',
       '6': '6px',
       '8': '8px',
      }
    },
  },
  plugins: [],
}

