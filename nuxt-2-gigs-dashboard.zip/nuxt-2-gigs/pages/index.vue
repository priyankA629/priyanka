
<template>
  <div>

     <Navigation />
 <!-- <ul class="divide-y divide-gray-200">
    <li v-for="peoples in people" :key="peoples.email" class="py-4 flex">
      <img class="h-10 w-10 rounded-full" :src="peoples.image" alt="" />
      <div class="ml-3">
        <p class="text-sm font-medium text-gray-900">{{ peoples.name }}</p>
        <p class="text-sm text-gray-500">{{ peoples.email }}</p>
      </div>
    </li>
  </ul>
  <div class="p-6 max-w-sm mx-auto bg-white rounded-xl shadow-lg flex items-center space-x-4">
  <div class="shrink-0">
    <img class="size-12" src="/img/logo.svg" alt="ChitChat Logo">
  </div>
  <div>
    <div class="text-xl font-medium text-black">ChitChat</div>
    <p class="text-slate-500">You have a new message!</p>
  </div>

</div>
<div class="p-6 bg-blue-500 text-white">
    Hello, Tailwind CSS with Nuxt 2!
  </div> -->
  </div>
</template>

<script>
import Navigation from '~/components/Navigation.vue'
export default {
  layout: 'dashboard',
  components: { Navigation },
  data () {
    return {
//    people : [
//   {
//     name: 'Calvin Hawkins',
//     email: 'calvin.hawkins@example.com',
//     image:
//       'https://images.unsplash.com/photo-1491528323818-fdd1faba62cc?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',
//   },
//   {
//     name: 'Kristen Ramos',
//     email: 'kristen.ramos@example.com',
//     image:
//       'https://images.unsplash.com/photo-1550525811-e5869dd03032?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',
//   },
//   {
//     name: 'Ted Fox',
//     email: 'ted.fox@example.com',
//     image:
//       'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',
//   },
// ]
}
  }
}
</script>

