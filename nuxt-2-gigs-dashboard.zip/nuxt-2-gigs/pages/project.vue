<template>
  <div>
    <Navigation />
   <div>
     <h5 class="py-7 font-bold text-xl">kanban</h5> 
     <KanbanTabs :tabs="tabs" v-model="selectedTab" >
     <template v-slot:Projects>
        <div class="flex space-x-4">
          <DragableColumn title="In Planning" :cards="inPlanningCards"  @move-card="moveCard" />
          <DragableColumn title="In Execution" :cards="inExecutionCards"  @move-card="moveCard" />
          <DragableColumn title="Completed" :cards="completedCards" @move-card="moveCard" />
        </div>
      </template>
     </KanbanTabs>
   </div>
  </div>
</template>
<script>
import Navigation from '~/components/Navigation.vue'
import KanbanTabs from '~/components/KanbanTabs.vue'
import DragableColumn from '~/components/DragableColumn.vue'
export default {
  
  layout: 'dashboard',
   components: { 
    Navigation ,
    KanbanTabs,
    DragableColumn
    },
     data () {
    return {
      tabs: ['Jobs', 'Contracts', 'Projects'],
      selectedTab: 'Projects',
      inPlanningCards: [
        {
          id: 'CON22148',
          status: 'Draft',
          title: 'CMS web application for Event Management Company',
          description: 'Web, Mobile & Software Development',
          industry: 'Ecommerce',
          type: 'Small Job',
          requirementsCount: 1,
          publishedDate: '2024-05-28',
          startDate: '2024-05-28'
        }
      ],
      inExecutionCards: [
        {
          id: 'CON22148',
          status: 'Active',
          title: 'Android App Development',
          description: 'Web, Mobile & Software Development',
          industry: 'Ecommerce',
          type: 'Small Job',
          requirementsCount: 1,
          publishedDate: '2024-05-28',
          startDate: '2024-05-28'
        },
        {
          id: 'CON22148',
          status: 'Overdue',
          title: 'Android App Development',
          description: 'Web, Mobile & Software Development',
          industry: 'Ecommerce',
          type: 'Small Job',
          requirementsCount: 1,
          publishedDate: '2024-05-28',
          startDate: '2024-05-28'
        }
      ],
      completedCards: [
        {
          id: 'CON22148',
          status: 'Active',
          title: 'Web App Development',
          description: 'Web, Mobile & Software Development',
          industry: 'Ecommerce',
          type: 'Small Job',
          requirementsCount: 1,
          publishedDate: '2024-05-28',
          startDate: '2024-05-28'
        }
      ],
      draggedCard: null,
      draggedIndex: null,
      draggedColumn: null
    }
},
 methods: {
    moveCard({ card, sourceIndex, sourceColumn, targetColumn }) {
      const source = this.getColumn(sourceColumn);
      const target = this.getColumn(targetColumn);

      // Remove card from source column
      source.splice(sourceIndex, 1);

      // Add card to target column
      target.push(card);
    },
    getColumn(columnName) {
      switch (columnName) {
        case 'In Planning':
          return this.inPlanningCards;
        case 'In Execution':
          return this.inExecutionCards;
        case 'Completed':
          return this.completedCards;
        default:
          return [];
      }
    }
  }
}
</script>

