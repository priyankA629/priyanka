<template>
  <div class="dashboard-layout">
    <Sidebar
      :menuItems="menuItems"
      :activeItem="activeItem"
      @set-active-item="handleActiveItemChange"
    />

    <div class="main-section">
      <Header />
      <MainContent />
    </div>
  </div>
</template>

<script>
import Sidebar from "~/components/Sidebar.vue";
import Header from "~/components/Header.vue";
import MainContent from "~/components/MainContent.vue";

export default {
  components: {
    Sidebar,
    Header,
    MainContent,
  },
  mounted() {
    this.$router.push('/project');
  },
  data() {
    return {
      menuItems: [
        { icon: ["fas", "tachometer-alt"], label: "Dashboard", link: "/" },
        { label: "Home", link: "/project", icon: ["fas", "home"] },
        { icon: ["fas", "briefcase"], label: "Jobs", link: "/" },
        { label: "Chat", link: "/project", icon: "fas fa-comments" },
        { label: "My Network", link: "/", icon: "fas fa-users" },
        {
          label: " Refer a Friend",
          link: "/project",
          icon: "fas fa-user-friends",
        },
        { label: "Coupon", link: "/", icon: "fas fa-ticket-alt" },
        { label: "Settings", link: "/project", icon: "fas fa-cog" },
      ],
      //    isCollapsed: false
      activeItem: "Jobs",
    };
  },
  methods: {
    handleActiveItemChange(newItem) {
      this.activeItem = newItem; 
    }
    // toggleSidebar() {
    //   this.isCollapsed = !this.isCollapsed;
    // }
  },
};
</script>