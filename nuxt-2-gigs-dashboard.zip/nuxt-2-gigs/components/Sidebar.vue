<template>
  <aside
    :class="[
      'h-auto shadow-md transition-all duration-500 ease-in-out',
      isCollapsed ? 'w-20' : 'w-64',
      'bg-white',
    ]"
  >
    <div class="sidebar-content p-6">
      <div class="flex items-center justify-center mb-5">
        <img
          v-if="!isCollapsed"
          src="~/assets/images/logo.png"
          alt="Logo"
          width="150"
          height="150"
          class="mr-3"
        />
      </div>
      <button
        @click="toggleSidebar()"
        :class="[
          'shadow-md w-10 h-10 bg-white rounded-full collapse-btn relative z-30 focus:outline-none transition-all duration-500 ease-in-out',
          isCollapsed ? 'ml-5' : 'ml-52',
        ]"
      >
        <i :class="['fas', isCollapsed ? 'chevron-right' : 'chevron-left']">
        </i>
      </button>
      <nav>
        <ul>
          <li
            v-for="item in menuItems"
            :key="item.text"
            :to="item.link"
          >
            <a
            @click="setActive(item.label)"
            class="mb-3 p-3 rounded-lg hover:bg-customTransparent hover:text-customPurple flex items-center font-sans text-sm font-medium"
             :class="[item.label === 'Jobs' ? 'bg-customTransparent text-customPurple font-bold' : (activeItem === item.label ? 'text-purple-600 font-bold' : 'text-gray-600'),
             'flex items-center hover:text-purple-600']"
              href="#"
            >
              <!-- <span class="pr-4"> -->
              <fa :icon="item.icon" class="mr-3"></fa>
              <!-- </span> -->
              <span v-if="!isCollapsed"> {{ item.label }} </span>
            </a>
          </li>
        </ul>
      </nav>
      <div
        class="mt-6 p-5 rounded-md bg-customPurple text-center"
        v-if="!isCollapsed"
      >
        <p class="text-base text-white pb-5">Try Mobile App Version</p>
        <button
          class="rounded-full py-3 px-6 bg-white text-customText text-sm focus:outline-none"
        >
          Download
        </button>
      </div>
    </div>
  </aside>
</template>

<script>
export default {
  name: "SidebarMenu",
  props: {
    icon: {
      type: Array,
      required: true,
    },
    menuItems: {
      type: Array,
      required: true,
    },
    activeItem: {
      type: String,
      required: true
    }
    //   isCollapsed: {
    //   type: Boolean,
    //   default: false,
    // }
  },
  data() {
    return {
      isCollapsed: false,
      // activeItem: 'Jobs',
    };
  },
  methods: {
    toggleSidebar() {
      this.isCollapsed = !this.isCollapsed;
    },
    setActive(label) {
      // this.$emit('set-active-item', label);
      if (label !== 'Jobs') {
        this.$emit('set-active-item', label)
      }
    }
  },
};
</script>