<template>
  <main class="main-content">
    <nuxt />
  </main>
</template>

<script>
export default {
  name: "MainContent",
};
</script>