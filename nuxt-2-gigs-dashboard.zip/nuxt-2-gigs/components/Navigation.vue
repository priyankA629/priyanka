<template>
  <div>
    <nav>
      <ul class="nav-ul">
        <li >
          <nuxt-link to="/" exact-active-class="active" >Home /</nuxt-link>
        </li>
        <li>
          <nuxt-link to="/project" active-class="active" >Project</nuxt-link>
        </li>
      </ul>
    </nav>
  </div>
</template>

<script>
export default {
  name: "Navigation",
  data() {
    return {
      items: [
        {
          text: "Admin",
          href: "#",
        },
        {
          text: "Manage",
          href: "#",
        },
      ],
    };
  },
};
</script>
<style scoped>
</style>