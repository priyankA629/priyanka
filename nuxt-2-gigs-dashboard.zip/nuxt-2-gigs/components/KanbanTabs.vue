<template>
  <div>
    <div
      class="flex justify-between bg-white w-auto h-auto shadow-md rounded-xl p-3"
    >
      <div class="flex justify-between items-center">
        <button
          v-for="tab in tabs"
          :key="tab"
          :class="[
            'px-9 py-2 mr-4 rounded-lg text-sm',
            {
              'px-9 py-2 mr-4 rounded-lg text-sm text-customPurple bg-customTransparent font-bold border-none':
                tab === selectedTab,
            },
          ]"
          class="border border-custom-purple focus:outline-none"
          @click="selectTab(tab)"
        >
          {{ tab }}
        </button>
      </div>
      <span class="mt-1">
        <input class="form-control mr-sm-2 placeholder-gray-500" placeholder="Search in Jobs" />
      </span>
    </div>

    <div class="tab-content">
      <slot :name="selectedTab"></slot>
    </div>
  </div>
</template>

<script>
export default {
  name: "Tabs",
  props: {
    tabs: {
      type: Array,
      required: true,
    },
    // selectedTab: {
    //   type: String,
    //   required: true
    // }
  },
  data() {
    return {
      selectedTab: this.tabs[2],
    };
  },
  methods: {
    selectTab(tab) {
      this.selectedTab = tab;
    },
  },
};
</script>