<template>
  <header class="m-3 bg-white w-auto h-auto shadow-md rounded">
    <div class="flex flex-row justify-between p-3">
      <input
        type="text"
        placeholder="Search"
        class="search-bar focus:outline-none"
      />
      <div class="flex items-center">
        <button
          class="text-sm bg-customTransparent text-customPurple focus:outline-none px-4 py-2 rounded mr-4"
        >
          Complete your profile
          <span
            class="text-sm font-semibold text-customPurple focus:outline-none"
            ><a class="text-customPurple">Lets Go</a></span
          >
        </button>
        <button
          class="flex items-center focus:outline-none px-4 py-2 rounded mr-4 bg-customtextBg"
        >
          <span><img src="~/assets/images/Board.svg" class="pr-2" /></span>
          <span class="text-sm text-customText">Board</span>
        </button>
        <button
          class="flex items-center px-4 py-2 rounded mr-4 bg-customtextBg divide-x divide-gray-400 focus:outline-none"
        >
          <span class="px-1"
            ><img src="~/assets/images/notofication.svg"
          /></span>
          <span class="px-1"><img src="~/assets/images/question.svg" /></span>
          <span class="px-1"
            ><img src="~/assets/images/thumbs-up-trust.svg"
          /></span>
        </button>

        <img
          src="~/assets/images/amman.png"
          alt="User Avatar"
          class="rounded-full"
          width="40"
          height="40"
        />
        <span class="ml-2">
          <p class="text-base font-semibold">Aman</p>
          <p class="text-sm font-light">customer</p>
        </span>

        <div class="rounded-full w-10 h-10 bg-customPurple ml-2">
          <!-- <span><img src="" />&#8593;</span> -->
          <i class="fas fa-arrow-left text-white-600 mr-4"></i>
        </div>
      </div>
    </div>
  </header>
</template>

<script>
export default {
  name: "Header",
};
</script>