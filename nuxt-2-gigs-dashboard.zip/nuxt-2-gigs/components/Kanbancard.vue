<template>
  <div 
  :class="['bg-white p-4 rounded-lg shadow-md mb-4', borderColorClass(card.status)]"
  class="bg-white p-4 rounded-lg shadow-md mb-4 mt-4">
    <div class="mb-2 justify-between flex align-center">
      <span class="text-gray-400">#{{ card.id }}</span>
      <span :class="statusClass(card.status)" class="px-2 py-1 rounded text-sm">
        {{ card.status }}
      </span>
    </div>
    <h6 class="text-base font-bold mb-2">{{ card.title }}</h6>
    <p class="text-gray-600 mb-2">{{ card.description }}</p>
    <div class="flex justify-between space-x-4">
      <p class="">
        <span class="text-sm text-gray-600"> Industry vertical: </span>
        <span class="text-sm text-gray-700 font-semibold">{{
          card.industry
        }}</span>
      </p>
      <p class="">
        <span class="text-sm text-gray-600"> Type: </span>
        <span class="text-sm text-gray-700 font-semibold">{{
          card.type
        }}</span>
      </p>
    </div>
    <p class="text-sm text-gray-600 mt-2">Requirements count:</p>

    <p class="text-sm text-gray-700 font-semibold">
      {{ card.requirementsCount }}
    </p>
    <div class="flex justify-between">
      <p>
        <span class="text-sm text-gray-600">Published Date: </span>

        <span class="text-sm text-gray-700 font-semibold">{{
          card.publishedDate
        }}</span>
      </p>
      <p class="pl-5">
        <span class="text-sm text-gray-600"> Start Date:</span>
        <span class="text-sm text-gray-700 font-semibold">{{
          card.startDate
        }}</span>
      </p>
    </div>
  </div>
</template>

<script>
export default {
  name: "KanbanCard",
  props: {
    card: {
      type: Object,
      required: true,
    },
  },
  methods: {
    statusClass(status) {
      switch (status) {
        case "Draft":
          return "bg-gray-200 text-gray-600 px-4 py-1 rounded-full";
        case "Active":
          return "bg-green-200 text-green-600 px-4 py-1 rounded-full";
        case "Overdue":
          return "bg-yellow-200 text-yellow-600 px-4 py-1 rounded-full";
        default:
          return "";
      }
    },
    borderColorClass(status) {
      switch (status) {
        case 'Draft':
          return 'border-t-3 border-gray-300'
        case 'Active':
          return 'border-t-3 border-green-300'
        case 'Overdue':
          return 'border-t-3 border-yellow-300'
        default:
          return 'border-t-3 border-gray-300'
      }
    },
  },
};
</script>