<template>
  <div>
    <div
      class="rounded-lg p-4 bg-customTransparent divide-y divide-gray-300 mt-4"
      @dragover.prevent
      @drop="drop($event)"
    >
      <h5 class="heading-text text-base text-black font-bold pb-2 ">
        {{ title }}
      </h5>
      <hr />
      <div
        v-for="(card, index) in cards"
        :key="card.id"
        :draggable="true"
        @dragstart="dragStart($event, card, index)"
        @dragend="dragEnd($event)"
      >
        <KanbanCard :card="card" />
      </div>
    </div>
  </div>
</template>

<script>
import KanbanCard from "./Kanbancard.vue";

export default {
  name: "KanbanColumn",
  components: {
    KanbanCard,
  },
  props: {
    title: {
      type: String,
      required: true,
    },
    cards: {
      type: Array,
      required: true,
    },
  },
  methods: {
    dragStart(event, card, index) {
      event.dataTransfer.setData("card", JSON.stringify(card));
      event.dataTransfer.setData("sourceIndex", index);
      event.dataTransfer.setData("sourceColumn", this.title);
    },
    dragEnd(event) {},
    drop(event) {
      const card = JSON.parse(event.dataTransfer.getData("card"));
      const sourceIndex = event.dataTransfer.getData("sourceIndex");
      const sourceColumn = event.dataTransfer.getData("sourceColumn");
      this.$emit("move-card", {
        card,
        sourceIndex,
        sourceColumn,
        targetColumn: this.title,
      });
    },
  },
};
</script>
