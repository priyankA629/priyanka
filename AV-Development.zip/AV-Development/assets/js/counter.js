// sub menu script
// [...document.querySelectorAll(".dropdown-menu")].forEach(megaMenu => {
//     megaMenu.addEventListener('click', (event) => {
//         event.stopPropagation();
//     }, false);
// });
// let btnContainers = document.getElementById("navbar_menu");
// let btnsObj = btnContainers.getElementsByClassName("btn");

// for (let i = 0; i < btnsObj.length; i++) {
//     btnsObj[i].addEventListener("click", (e) => {
//         console.log(e.target.closest(".btn"));
//         e.target.closest(".mega-area").classList.toggle("show")
//     })
// }

// const number = [3, 2, 1, 4];
// var i;
// var l;
// var max = Infinity;
// var findNonMinOrMax = function (nums) {
//   for (i = 0; number[i] > i; i++) {
//     if (number[i] > number) {
//       debugger;
//       console.log(i + " lowest number" + number[i]);
//       l = number[i];
//     }
//     debugger;
//     console.log(l);
//   }
//   console.log(l);
// };
// function findMiddle(nums) {
//         // if (nums.length < 3) {
//         //     return -1;
//         // }
    
//         // Sort the array
        
//         nums.sort((a, b) => a - b);
       
//         // Return the element at index 1 (the second smallest element)
//         // return nums[1];
//       debugger;
//     }
    
//     // Example usage:
//     const nums = [3, 1, 5, 4, 2];
//     const result = findMiddle(nums);
    
//     console.log("Number:", result);
function twoSum(nums, target) {
        const numIndices = {};
    
        for (let i = 0; i < nums.length; i++) {
            const complement = target - nums[i];
            debugger;
            if (complement in numIndices) {
                debugger;
                return [numIndices[complement], i];
            }
            debugger;
            numIndices[nums[i]] = i;
        }
    
        // If no solution is found
        return [];
    }
    
    // Example usage:
    const nums = [2, 7, 11, 15];
    const target = 9;
    const result = twoSum(nums, target);
    console.log("Indices:", result);
